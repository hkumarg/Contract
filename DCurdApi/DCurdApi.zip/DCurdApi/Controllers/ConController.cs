﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DCurdApi.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DCurdApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConController : ControllerBase

    {
        private readonly ContractRepository contractRepository;

        public ConController()
        {
            contractRepository = new ContractRepository();

        }

        [HttpGet]
        public IEnumerable<Contract> Get()
        {
            return contractRepository.GetAll();
        }

        [HttpGet("{id}")]
        public Contract Get(int id)
        {
            return contractRepository.GetById(id);
        }

        [HttpPost]
        public void Post([FromBody]Contract con)
        {
            if (ModelState.IsValid)
                contractRepository.Add(con);
        }

        [HttpPut("{id}")]
        public void Put(int id, [FromBody]Contract con)
        {
            if (ModelState.IsValid)
                contractRepository.Update(id, con);
        }

        [HttpDelete]
        public void Delete(int id)
        {
            contractRepository.DeleteById(id);
        }
        /*
        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
        */
    }
}
